﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace color_blind_sem_erros_pt1
{
    public partial class Form16 : Form
    {
        public Form16(string nome)
        {
            InitializeComponent();
            textBox2.Text = "Bem-vindo, " + nome + "!";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                Form6 form16 = new Form6();

                form16.Show();
                this.Hide();

                MessageBox.Show("Acertaste " + certo + " vezes");
            }
        }
        private int certo = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            {
                if (textBox1.Text == "4")
                {
                    MessageBox.Show("Acertaste");
                    certo++;
                }
            }
        }
    }
}