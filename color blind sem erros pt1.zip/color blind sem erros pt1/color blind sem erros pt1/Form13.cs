﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace color_blind_sem_erros_pt1
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form14 form12 = new Form14();

            form12.Show();
            this.Hide();
            MessageBox.Show("Acertaste " + certo + " vezes");
        }
        private int certo = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            {
                if (textBox1.Text == "7")
                {
                    MessageBox.Show("acertaste");
                    certo++;
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
