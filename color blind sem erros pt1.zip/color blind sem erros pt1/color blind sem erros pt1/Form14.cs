﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace color_blind_sem_erros_pt1
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form17 form14 = new Form17();

            form14.Show();
            this.Hide();
            MessageBox.Show("Acertaste " + certo + " vezes");
        }
        private int certo = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            {
                if (textBox1.Text == "2")
                {
                    MessageBox.Show("acertaste");
                    certo++;
                    MessageBox.Show( "Acertos: " + certo);
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
