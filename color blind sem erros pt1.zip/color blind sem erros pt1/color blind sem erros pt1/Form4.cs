﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms.VisualStyles;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace color_blind_sem_erros_pt1
{
    public partial class Form4 : Form
    {
       
        public Form4()
        {
           
        }

        private void LCDTV_TextChanged(object sender, EventArgs e)
        {

        }


        class Program
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 form4 = new Form6();

            form4.Show();
            this.Hide();
        }

        private void LCDTV_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
            {
               
            }



        }
    }

