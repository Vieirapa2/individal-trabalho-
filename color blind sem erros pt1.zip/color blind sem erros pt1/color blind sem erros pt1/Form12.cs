﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace color_blind_sem_erros_pt1
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form13 form11 = new Form13();

            form11.Show();
            this.Hide();
            MessageBox.Show("Acertaste " + certo + " vezes");
        }
        private int certo = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            {
                if (textBox1.Text == "6")
                {
                    MessageBox.Show("acertaste");
                    certo++;
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
