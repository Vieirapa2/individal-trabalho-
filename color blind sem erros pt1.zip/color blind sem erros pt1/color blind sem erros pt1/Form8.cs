﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace color_blind_sem_erros_pt1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }

        private void LCDTV_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form9 form7 = new Form9();

            form7.Show();
            
            this.Hide();
            MessageBox.Show("Acertaste " + certo + " vezes");
        }
        private int certo = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            {
                if (textBox1.Text == "5")
                {
                    MessageBox.Show("Acertaste");
                    certo++;
                }
            }
        }
    }
}
